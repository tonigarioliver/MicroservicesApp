package com.antonigari.GrpcServerService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpcServerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
